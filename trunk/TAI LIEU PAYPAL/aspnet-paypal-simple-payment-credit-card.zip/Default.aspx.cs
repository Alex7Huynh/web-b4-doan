﻿using System;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;


public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //PayPalGateway pp = new PayPalGateway();
        //string rv = pp.Pay("123", "1", "Minh", "Phuong", "123 Nguyen Hue", "HCM", "CA", "US", "United States", "12345", "Visa", "4490701599080019", "", "2", "2015");
        //string rv = pp.GetTransactionDetails("6XT85330WL909250J");
        //Response.Write(rv);
    }
    
    protected void btnExpressCheckout_Click(object sender, ImageClickEventArgs e)
    {
        //Get Token

    }

    protected void btnCreditCard_Click(object sender, ImageClickEventArgs e)
    {
        PayPalGateway pp = new PayPalGateway();
        PayPalReturn rv = pp.Pay("123", "1", "Minh", "Phuong", "123 Nguyen Hue", "HCM", "CA", "US", "United States", "12345", "Visa", "4490701599080019", "027", "2", "2015");
        if (rv.IsSucess)
        {
            lblMsg.Text = "Your Invoice Number: " + rv.TransactionID;
        }
        else
        {
            lblMsg.Text = "Error process: " + rv.ErrorMessage;
        }
    }
}
